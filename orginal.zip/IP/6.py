import pandas as pd

s1 = pd.Series([10, 20, 30, 40], index=["a", "b", "c", "d"])
s2 = pd.Series([10, 20, 40, 60], index=["a", "b", "d", "f"])

print(f"s1[::-1]:\n{s1[::-1]}")
print()
print(f"s1[:2]:\n{s2[:2]}")
print()
print(f"s1[:2] * 100:\n{s1[:2] * 100}")
