import matplotlib.pyplot as plt

x = ["Jan", "Feb", "March", "Apr", "May", "June"]
y = [69, 39, 79, 29, 12, 24]

plt.plot(x, y)
plt.show()
