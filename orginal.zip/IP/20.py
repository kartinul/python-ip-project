import matplotlib.pyplot as plt

ages = [22, 24, 22, 23, 25, 30, 29, 28, 25, 22, 24, 27, 29, 31, 30, 22, 23, 25, 26, 28]

plt.hist(ages)

plt.show()
