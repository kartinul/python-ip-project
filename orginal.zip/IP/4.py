import pandas as pd

array1 = pd.array([10, 42, 523, 63, 85])

series = pd.Series(array1)

print(series)
print(f"size: {series.size}")
print(f"index: {list(series.index)}")
print(f"shape: {series.shape}")
